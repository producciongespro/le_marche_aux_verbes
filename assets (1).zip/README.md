<h1> Le-Marche-Aux-Verbs </h1>

<strong>Recurso lúdico </strong> que trabaja con tarjetas de verbos en francés en diferentes tiempos verbales:
* Pasado compuesto
* Futuro simple
* Presente.

A su vez, trabaja con tarjetas con los significados de los verbos en español.
<hr>
Puede probar el recurso 

* Online (HTML): https://producciongespro.github.io/Le-Marche-Aux-Verbes/
* Googe Play store: https://play.google.com/store/apps/details?id=com.gespro.varbs_fair
  
